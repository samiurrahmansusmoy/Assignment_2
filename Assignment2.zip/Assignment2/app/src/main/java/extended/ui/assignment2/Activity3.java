package extended.ui.assignment2;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Activity3 extends AppCompatActivity {

    TextView t1;
    String st;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);
        t1=findViewById(R.id.textView);
        st=getIntent().getExtras().getString("Value");
        t1.setText(st);
    }
}
