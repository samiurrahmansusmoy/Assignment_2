package extended.ui.assignment2;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Activity4 extends AppCompatActivity {
    Button btn2;
    EditText et2 ;
    String st2 ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_4);
        btn2 = findViewById(R.id.button3);
        et2 = findViewById(R.id.editTextTextPersonName2);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity5();
            }
        });
    }
    public void openActivity5(){
        Intent i2 = new Intent(Activity4.this,Activity5.class);
        st2 = et2.getText().toString();
        i2.putExtra("Value",st2);
        startActivity(i2);
        finish();

    }

}

