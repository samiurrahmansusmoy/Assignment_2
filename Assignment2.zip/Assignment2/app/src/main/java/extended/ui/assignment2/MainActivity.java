package extended.ui.assignment2;
import androidx.appcompat.app.AppCompatActivity;



import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    Button btn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner sp = findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.select, android.R.layout.simple_spinner_item );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(adapter);
        sp.setOnItemSelectedListener(this);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch (position) {
            case 0:

                btn = findViewById(R.id.button);
                btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        openActivity2();
                    }
                });
                break;


//            case 1:
//                btn = findViewById(R.id.button);
//                btn.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        openActivityDirect();
//                    }
//                });
//                break;
            case 2:
                btn = findViewById(R.id.button);
                btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        openActivity4();
                    }
                });
                break;
            default:
        }
    }

    public void openActivity2(){
        Intent i = new Intent(MainActivity.this,Activity2.class);
        startActivity(i);


    }


//    public void openActivityDirect(){
//        Intent i = new Intent(MainActivity.this,Activity5.class);
//        startActivity(i);


   // }
    public void openActivity4(){
        Intent i = new Intent(MainActivity.this,Activity4.class);
        startActivity(i);


    }



    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
